#!/bin/sh

fn_flash_128M ()
{
    ./gigaflash ../../../fw/373.bin -2400
}

fn_flash_256M ()
{
    ./gigaflash ../../../fw/773.bin -2400
}

fn_show_help ()
{
    echo "Please enter correct parameter:"
	echo "./flash -256M"
	echo "./flash -128M"
}

chmod +x gigaflash
chmod +x socflash

if [ $1 = "-128M" ]; then
	fn_flash_128M
elif [ $1 = "-256M" ]; then
	fn_flash_256M
else
    fn_show_help
fi
