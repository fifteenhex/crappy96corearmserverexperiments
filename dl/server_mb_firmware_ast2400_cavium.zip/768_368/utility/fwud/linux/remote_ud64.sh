#! /bin/bash


if [ "$1" == "" ] || [ "$2" == "" ] || [ "$3" == "" ] || [ "$4" == "" ]; then
        echo "[USAGE]:"
        echo "        $0 [IP Address] [UserName] [Password] [File Path] [Clear Settings=y/N]"
        echo "[PURPOSE]:"
        echo "        Remote Update BMC Firmware"
        echo ""
        exit 0
fi

IPAddr=$1
USERNAME=$2
PASSWORD=$3
FILEPATH=$4
CLEARSETTING=$5


cd 64bit
export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH

chmod a+x bmcfwul

if [ "$CLEARSETTING" == "y" ] || [ "$CLEARSETTING" == "Y" ]; then
	./bmcfwul -c -mode=remote -uri=$FILEPATH -n=lanplus -H=$IPAddr -U=$USERNAME -P=$PASSWORD -F -D=10 -I=10 -R=10 -C=1
else
	./bmcfwul -mode=remote -uri=$FILEPATH -n=lanplus -H=$IPAddr -U=$USERNAME -P=$PASSWORD -F -D=10 -I=10 -R=10 -C=1
fi

cd ..
