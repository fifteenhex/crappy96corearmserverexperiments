#!/bin/bash

fn_flash_128M ()
{
	echo Update Firmware for BMC with 128M
	echo Update Root File System
	./socflash cs=0 if=../../../fw/368.bin offset=0x6C0000 count=0x1400000 skip=0x6C0000

	echo Update Kernel
	./socflash cs=0 if=../../../fw/368.bin offset=0x2C0000 count=0x300000 skip=0x2C0000

	echo Update Bootloader
	./socflash cs=0 if=../../../fw/368.bin count=0xc0000
}

fn_flash_256M ()
{
	echo Update Firmware for BMC with 256M
	echo Update Root File System
	./socflash cs=0 if=../../../fw/768.bin offset=0x6C0000 count=0x1400000 skip=0x6C0000

	echo Update Kernel
	./socflash cs=0 if=../../../fw/768.bin offset=0x2C0000 count=0x300000 skip=0x2C0000

	echo Update Bootloader
	./socflash cs=0 if=../../../fw/768.bin count=0xc0000
}

./read > hwstrap.reg
./memsize hwstrap.reg
retval=$?

if [ $retval -eq 1 ]; then
	fn_flash_128M
elif [ $retval -eq 2 ]; then
	fn_flash_256M
else
	echo "unknown DDR Size."
fi

rm -rf hwstrap.reg

echo Wait 90 seconds for BMC Ready...
sleep 90

