#!/bin/bash

fn_flash_128M ()
{
	echo Update Firmware for BMC with 128M
	echo Update Root File System
	./socflash_x64 cs=0 if=../../../fw/372.bin offset=0x6C0000 count=0x1400000 skip=0x6C0000

	echo Update Kernel
	./socflash_x64 cs=0 if=../../../fw/372.bin offset=0x2C0000 count=0x300000 skip=0x2C0000

	echo Erase User Configuration
	./socflash_x64 cs=0 if=../../../fw/372.bin offset=0xC0000 count=0x200000 skip=0xC0000

	echo Update Bootloader
	./socflash_x64 cs=0 if=../../../fw/372.bin count=0xc0000
}

fn_flash_256M ()
{
	echo Update Firmware for BMC with 256M
	echo Update Root File System
	./socflash_x64 cs=0 if=../../../fw/772.bin offset=0x6C0000 count=0x1400000 skip=0x6C0000

	echo Update Kernel
	./socflash_x64 cs=0 if=../../../fw/772.bin offset=0x2C0000 count=0x300000 skip=0x2C0000

	echo Erase User Configuration
	./socflash_x64 cs=0 if=../../../fw/772.bin offset=0xC0000 count=0x200000 skip=0xC0000

	echo Update Bootloader
	./socflash_x64 cs=0 if=../../../fw/772.bin count=0xc0000
}

ipmitool raw 0x2e 0x20 0x0a 0x3c 0x00 0x24 0x00
./read > hwstrap.reg
./memsize hwstrap.reg
retval=$?

if [ $retval -eq 1 ]; then
	fn_flash_128M
elif [ $retval -eq 2 ]; then
	fn_flash_256M
else
	echo "unknown DDR Size."
fi

rm -rf hwstrap.reg

echo Wait 90 seconds for BMC Ready...
sleep 90

